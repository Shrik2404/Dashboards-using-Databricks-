# Databricks notebook source
# MAGIC %md ## Lab 2: Databricks SQL Query <br>
# MAGIC Student's name: ATHARVA SHRIKHANDE<br>
# MAGIC Student G#: G01462301<br>
# MAGIC Class section #: AIT 614-Sec-02<br>

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from em_attr

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from em_attr

# COMMAND ----------

# MAGIC %sql
# MAGIC select Age, Department, HourlyRate, Education from em_attr
# MAGIC where TotalWorkingYears between 5 and 25
# MAGIC and Attrition == "Yes"

# COMMAND ----------

# MAGIC %sql
# MAGIC --(15 points) Count the employees whose TotalWorkingYears are greater than 20.
# MAGIC SELECT COUNT(EmployeeNumber)
# MAGIC FROM em_attr
# MAGIC WHERE TotalWorkingYears > 20;
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC --Find EmployeeNumber, EducationField, JobRole for all the employees whose
# MAGIC --Age is between 25 and 30 and Education is 5. Display only EmployeeNumber,
# MAGIC --EducationField, and JobRobe in the output. Then visualize the queries in a dashboard. You
# MAGIC --can choose any chart to visualize your results.
# MAGIC SELECT EmployeeNumber, EducationField, JobRole
# MAGIC FROM em_attr
# MAGIC WHERE Age BETWEEN 25 AND 30 AND Education = 5;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC --For all the women employees having Age between 55 and 60 and
# MAGIC --TotalWorkingYears > 30, sort Age in descending order. Print only Age, EmployeeNumber,
# MAGIC --and Department in the output. Then visualize the queries in a dashboard. You can choose
# MAGIC --any chart to visualize your results.
# MAGIC
# MAGIC SELECT Age, EmployeeNumber, Department
# MAGIC FROM em_attr
# MAGIC WHERE Gender = 'Female' 
# MAGIC AND Age BETWEEN 55 AND 60 
# MAGIC AND TotalWorkingYears > 30
# MAGIC ORDER BY Age DESC;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC --Count the different MaritalStatus when Attrition is YES and AGE is greater than
# MAGIC --35 in the dataset. Arrange the count in ascending order. Then visualize the queries in a
# MAGIC --dashboard. You can choose any chart to visualize your results. 
# MAGIC
# MAGIC
# MAGIC
# MAGIC SELECT COUNT(MaritalStatus) as Total, MaritalStatus
# MAGIC FROM em_attr
# MAGIC WHERE Attrition = 'Yes' AND Age > 35
# MAGIC GROUP BY MaritalStatus
# MAGIC ORDER BY Total ASC

# COMMAND ----------

# MAGIC %md
# MAGIC References: <br>
# MAGIC <i>[1] Dr. Liao. Lab 2 Instructions … </i><br>
# MAGIC <i>[2] Dr. Liao. Lab 2 code example, Liao_dbfs_op_Databricks.html. </i><br>
# MAGIC <i>[3] Databricks. SQL Language Reference, https://docs.databricks.com/en/sql/language-manual/index.html. </i><br>
# MAGIC <i>[4] Databricks, https://www.databricks.com/</i>
